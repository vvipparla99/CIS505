

public interface ComposerDao extends GenericDao<Composer, Integer> {

	

}
